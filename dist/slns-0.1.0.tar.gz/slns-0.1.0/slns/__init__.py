"""
    Library of various utilities developed at the Simulation Laboratory Neuroscience (SLNS),
    of the Juelich Supercomputing Center.

"""

__version__ = '0.1.0'
